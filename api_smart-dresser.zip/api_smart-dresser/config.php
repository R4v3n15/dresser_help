<?php

$db = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'db' => 'ionic' //Cambiar al nombre de tu base de datos
];

?>
