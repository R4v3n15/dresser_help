<?php
    header("HTTP/1.1 200 OK");

    if ($_SERVER['REQUEST_METHOD'] == 'POST')
    {
        //codigo del metodo rest
    }
?>